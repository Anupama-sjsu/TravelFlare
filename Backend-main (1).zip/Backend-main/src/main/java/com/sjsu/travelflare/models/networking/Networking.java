package com.sjsu.travelflare.models.networking;

import org.springframework.stereotype.Component;

@Component
public class Networking {


}
