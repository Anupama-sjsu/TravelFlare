package com.sjsu.travelflare.models.response.exceptions;

public class ParameterMissingException extends Exception {

    public ParameterMissingException(final String message) {
        super(message);
    }
}
