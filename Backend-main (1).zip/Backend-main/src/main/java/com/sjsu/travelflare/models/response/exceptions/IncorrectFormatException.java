package com.sjsu.travelflare.models.response.exceptions;

public class IncorrectFormatException extends Exception {

    public IncorrectFormatException(final String message) {
        super(message);
    }
}
