package com.app.travel.flare.utils

interface HandleAlertListener {

    fun handlePositiveBtn()
    fun handleNegativeBtn()
}