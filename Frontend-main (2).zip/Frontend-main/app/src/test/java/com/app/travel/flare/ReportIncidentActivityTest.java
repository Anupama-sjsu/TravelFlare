package com.app.travel.flare;

import android.view.View;
import android.widget.Button;

import androidx.databinding.DataBindingUtil;

import com.app.travel.flare.databinding.ActivityReportIncidentBinding;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

public class ReportIncidentActivityTest {

//    @Rule
//    public ActivityTestRule<LoginActivity> loginActivityActivityTestRule =
//            new ActivityTestRule<LoginActivity>(LoginActivity.class);
//    private LoginActivity loginActivity = null;
//
//    @Before
//    public void setUp() throws Exception {
//        loginActivity = loginActivityActivityTestRule.getActivity();
//    }
//
//    @Test
//    public void testReportButton(){
//        ReportIncidentActivity activity = Mockito.mock(ReportIncidentActivity.class);
//
//        Button v = (Button) activity.findViewById(R.id.reportBtn);
//        Assert.assertNotNull(v);
//    }
}
